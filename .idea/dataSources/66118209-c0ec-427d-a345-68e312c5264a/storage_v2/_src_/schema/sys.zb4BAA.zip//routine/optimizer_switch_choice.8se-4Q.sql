create
    definer = `mariadb.sys`@localhost procedure optimizer_switch_choice(IN on_off varchar(3))
    comment 'return @@optimizer_switch options as a result set for easier readability'
    sql security invoker
BEGIN
  DECLARE tmp VARCHAR(1024);
  DECLARE opt VARCHAR(1024);
  DECLARE start INT;
  DECLARE end INT;
  DECLARE pos INT;
  set tmp=concat(@@optimizer_switch,",");
  CREATE OR REPLACE TEMPORARY TABLE tmp_opt_switch (a varchar(64), opt CHAR(3)) character set latin1 engine=heap;
  set start=1;
  FIND_OPTIONS:
  LOOP
    set pos= INSTR(SUBSTR(tmp, start), ",");
    if (pos = 0) THEN
       LEAVE FIND_OPTIONS;
    END IF;
    set opt= MID(tmp, start, pos-1);
    set end= INSTR(opt, "=");
    insert into tmp_opt_switch values(LEFT(opt,end-1),SUBSTR(opt,end+1));
    set start=start + pos;
  END LOOP;
  SELECT  t.a as "option",t.opt from tmp_opt_switch as t where t.opt = on_off order by a;
  DROP TEMPORARY TABLE tmp_opt_switch;
END;

